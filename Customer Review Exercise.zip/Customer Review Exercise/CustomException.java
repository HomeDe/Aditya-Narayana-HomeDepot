public class CustomException extends Exception {
	CustomException(String s){  
		  super(s);  
		 }  
}

      